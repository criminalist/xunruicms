# Slim Oracle PDO Example #

This is example for Oracle PDO connection example using PDO.
Please Install and Enable PHP OCI8 Extension for connection between PHP and Oracle

To Enable OCI8, open php.ini, find line 
``` ;extension=php_oci8.dll ``` 
and remove semicolon (;)
``` extension=php_oci8.dll ```

Do same in line 
``` ;extension=php_oci8_11g.dll ```
for Oracle Database 11G or ```;extension=php_oci8_12c.dll``` for Oracle Database 12C

