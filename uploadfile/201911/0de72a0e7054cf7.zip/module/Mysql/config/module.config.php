<?php
return [
    'controllers' => [
        'factories' => [
            'Mysql\\V1\\Rpc\\USER\\Controller' => \Mysql\V1\Rpc\USER\USERControllerFactory::class,
            'Mysql\\V1\\Rpc\\Ping\\Controller' => \Mysql\V1\Rpc\Ping\PingControllerFactory::class,
        ],
    ],
    'router' => [
        'routes' => [
            'mysql.rpc.user' => [
                'type' => 'Segment',
                'options' => [
                    'route' => 'API/USER',
                    'defaults' => [
                        'controller' => 'Mysql\\V1\\Rpc\\USER\\Controller',
                        'action' => 'uSER',
                    ],
                ],
            ],
            'mysql.rpc.ping' => [
                'type' => 'Segment',
                'options' => [
                    'route' => '/ping',
                    'defaults' => [
                        'controller' => 'Mysql\\V1\\Rpc\\Ping\\Controller',
                        'action' => 'ping',
                    ],
                ],
            ],
        ],
    ],
    'zf-versioning' => [
        'uri' => [
            0 => 'mysql.rpc.user',
            1 => 'mysql.rpc.ping',
        ],
    ],
    'zf-rpc' => [
        'Mysql\\V1\\Rpc\\USER\\Controller' => [
            'service_name' => 'USER',
            'http_methods' => [
                0 => 'GET',
            ],
            'route_name' => 'mysql.rpc.user',
        ],
        'Mysql\\V1\\Rpc\\Ping\\Controller' => [
            'service_name' => 'Ping',
            'http_methods' => [
                0 => 'GET',
            ],
            'route_name' => 'mysql.rpc.ping',
        ],
    ],
    'zf-content-negotiation' => [
        'controllers' => [
            'Mysql\\V1\\Rpc\\USER\\Controller' => 'Json',
            'Mysql\\V1\\Rpc\\Ping\\Controller' => 'Json',
        ],
        'accept_whitelist' => [
            'Mysql\\V1\\Rpc\\USER\\Controller' => [
                0 => 'application/vnd.mysql.v1+json',
                1 => 'application/json',
                2 => 'application/*+json',
            ],
            'Mysql\\V1\\Rpc\\Ping\\Controller' => [
                0 => 'application/vnd.mysql.v1+json',
                1 => 'application/json',
                2 => 'application/*+json',
            ],
        ],
        'content_type_whitelist' => [
            'Mysql\\V1\\Rpc\\USER\\Controller' => [
                0 => 'application/vnd.mysql.v1+json',
                1 => 'application/json',
            ],
            'Mysql\\V1\\Rpc\\Ping\\Controller' => [
                0 => 'application/vnd.mysql.v1+json',
                1 => 'application/json',
            ],
        ],
    ],
    'zf-content-validation' => [
        'Mysql\\V1\\Rpc\\Ping\\Controller' => [
            'input_filter' => 'Mysql\\V1\\Rpc\\Ping\\Validator',
        ],
    ],
    'input_filter_specs' => [
        'Mysql\\V1\\Rpc\\Ping\\Validator' => [
            0 => [
                'required' => true,
                'validators' => [],
                'filters' => [],
                'name' => 'ask',
                'description' => 'Вопросы и ответы',
            ],
        ],
    ],
];
