<?php
return [
    'Mysql\\V1\\Rpc\\Ping\\Controller' => [
        'description' => 'ASK',
        'GET' => [
            'description' => 'Ask ping',
            'response' => '{
   "ask": "Вопросы и ответы"
}',
        ],
    ],
];
