<?php
namespace Mysql\V1\Rpc\USER;

class USERControllerFactory
{
    public function __invoke($controllers)
    {
        return new USERController();
    }
}
