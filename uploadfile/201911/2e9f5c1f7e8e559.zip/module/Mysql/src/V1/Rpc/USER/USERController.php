<?php
namespace Mysql\V1\Rpc\USER;

use Zend\Mvc\Controller\AbstractActionController;

class USERController extends AbstractActionController
{
    public function uSERAction()
    {
    }
}
