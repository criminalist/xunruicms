<?php
return [
    'controllers' => [
        'factories' => [
            'Mysql\\V1\\Rpc\\USER\\Controller' => \Mysql\V1\Rpc\USER\USERControllerFactory::class,
        ],
    ],
    'router' => [
        'routes' => [
            'mysql.rpc.user' => [
                'type' => 'Segment',
                'options' => [
                    'route' => 'API/USER',
                    'defaults' => [
                        'controller' => 'Mysql\\V1\\Rpc\\USER\\Controller',
                        'action' => 'uSER',
                    ],
                ],
            ],
        ],
    ],
    'zf-versioning' => [
        'uri' => [
            0 => 'mysql.rpc.user',
        ],
    ],
    'zf-rpc' => [
        'Mysql\\V1\\Rpc\\USER\\Controller' => [
            'service_name' => 'USER',
            'http_methods' => [
                0 => 'GET',
            ],
            'route_name' => 'mysql.rpc.user',
        ],
    ],
    'zf-content-negotiation' => [
        'controllers' => [
            'Mysql\\V1\\Rpc\\USER\\Controller' => 'Json',
        ],
        'accept_whitelist' => [
            'Mysql\\V1\\Rpc\\USER\\Controller' => [
                0 => 'application/vnd.mysql.v1+json',
                1 => 'application/json',
                2 => 'application/*+json',
            ],
        ],
        'content_type_whitelist' => [
            'Mysql\\V1\\Rpc\\USER\\Controller' => [
                0 => 'application/vnd.mysql.v1+json',
                1 => 'application/json',
            ],
        ],
    ],
];
